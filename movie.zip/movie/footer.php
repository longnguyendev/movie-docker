<div class="mt-auto">
    <div class="footer mt-4">
        <div class="flex-footer">
            <div class="information-left" style="flex-grow: 2">
                <p>PANDA CINEMA Viet Nam</p>
                <p>COPYRIGHT © 2024 PANDA CINEMA Viet Nam</p>
            </div>
            <div class="information-ringht" style="flex-grow: 8">
                <addres>
                    <h4>Hotline: +84 0123456789</h4>
                    <h4>Email: cs.pandacinema@gmail.com</h4>
                </addres>
            </div>
        </div>
    </div>
</div>